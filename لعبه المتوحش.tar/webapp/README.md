# منصة لعبة المتوحش 🎮

منصة ألعاب تفاعلية لتنفيذ لعبة "المتوحش" - لعبة استراتيجية مثيرة للعب مع الأصدقاء (حتى 15 لاعب).

## 🌐 الروابط العامة

- **الموقع المحلي**: https://3000-idxsnlvza2h9jn7b08jjj-c07dda5e.sandbox.novita.ai
- **API Health Check**: https://3000-idxsnlvza2h9jn7b08jjj-c07dda5e.sandbox.novita.ai/api/health
- **GitHub**: (سيتم إضافته عند النشر)

## ✅ الميزات المكتملة

### نظام المصادقة والمستخدمين
- ✅ تسجيل حساب جديد
- ✅ تسجيل الدخول/الخروج
- ✅ إدارة الجلسات (Sessions)
- ✅ تشفير كلمات المرور
- ✅ التحقق من صحة البيانات

### نظام الغرف
- ✅ إنشاء غرفة جديدة (مع كود فريد)
- ✅ الانضمام لغرفة بالكود
- ✅ تحديد عدد المقاعد (5-20 لاعب)
- ✅ إدارة اللاعبين في الغرفة
- ✅ حذف الغرف (المضيف فقط)

### منطق اللعبة الكامل
- ✅ بدء اللعبة (اختيار متوحش عشوائي)
- ✅ نظام الأدوار (متوحش، مواطن، متفرج)
- ✅ قتل لاعب في كل جولة
- ✅ إعلان النبضين (قريب وبعيد)
- ✅ نظام التصويت الكامل
- ✅ المقعد العالي (تخمين المتوحش)
- ✅ نقل دور المتوحش لشخص آخر
- ✅ حساب الفائز تلقائياً

### نظام الدردشة والأحداث
- ✅ إرسال واستقبال الرسائل
- ✅ رسائل النظام والإعلانات
- ✅ سجل الأحداث الكامل

### الواجهة الأمامية الأساسية
- ✅ صفحة رئيسية
- ✅ صفحة تسجيل الدخول
- ✅ صفحة إنشاء حساب
- ✅ لوحة التحكم الأساسية
- ✅ عرض الغرف المتاحة

## 📋 API Endpoints المتاحة

### المصادقة (`/api/auth`)
- `POST /api/auth/register` - تسجيل حساب جديد
- `POST /api/auth/login` - تسجيل الدخول
- `POST /api/auth/logout` - تسجيل الخروج
- `GET /api/auth/me` - جلب بيانات المستخدم الحالي

### الغرف (`/api/rooms`)
- `POST /api/rooms` - إنشاء غرفة جديدة ✅ **Auth Required**
- `POST /api/rooms/join` - الانضمام لغرفة ✅ **Auth Required**
- `GET /api/rooms/:roomId` - جلب معلومات غرفة ✅ **Auth Required**
- `GET /api/rooms` - قائمة الغرف المتاحة ✅ **Auth Required**
- `DELETE /api/rooms/:roomId` - حذف غرفة ✅ **Host Only**

### اللعبة (`/api/game`)
- `POST /api/game/:roomId/start` - بدء اللعبة ✅ **Host Only**
- `GET /api/game/:roomId/my-role` - جلب دوري السري ✅ **Auth Required**
- `POST /api/game/:roomId/kill` - قتل لاعب ✅ **Mutawahhish Only**
- `POST /api/game/:roomId/pulse` - إعلان النبضين ✅ **Host Only**

### التصويت (`/api/vote`)
- `POST /api/vote/:roomId/cast` - التصويت ✅ **Alive Players Only**
- `POST /api/vote/:roomId/finalize` - إنهاء التصويت ✅ **Host Only**
- `POST /api/vote/:roomId/high-seat-guess` - تخمين المتوحش ✅ **High Seat Only**
- `POST /api/vote/:roomId/transfer-role` - نقل دور المتوحش ✅ **Old Mutawahhish Only**

### الدردشة (`/api/chat`)
- `GET /api/chat/:roomId/messages` - جلب الرسائل ✅ **Auth Required**
- `POST /api/chat/:roomId/send` - إرسال رسالة ✅ **Room Member Only**

## 🏗️ البنية التقنية

### Backend
- **Framework**: Hono (Fast web framework for Cloudflare)
- **Runtime**: Cloudflare Workers
- **Database**: Cloudflare D1 (SQLite)
- **Authentication**: JWT-like sessions with Web Crypto API

### Frontend
- **Framework**: Vanilla JavaScript + Axios
- **Styling**: TailwindCSS + FontAwesome
- **Architecture**: SPA (Single Page Application)

### Database Schema
- **users** - بيانات المستخدمين
- **sessions** - جلسات تسجيل الدخول
- **rooms** - الغرف
- **room_players** - اللاعبون في كل غرفة
- **player_roles** - أدوار اللاعبين
- **rounds** - جولات اللعبة
- **votes** - التصويتات
- **chat_messages** - الرسائل
- **game_events** - سجل الأحداث

## ⚙️ التطوير المحلي

```bash
# تثبيت التبعيات
npm install

# تطبيق migrations محلياً
npm run db:migrate:local

# إضافة بيانات تجريبية
npm run db:seed

# بناء المشروع
npm run build

# بدء الخادم المحلي
npm run dev:sandbox
# أو باستخدام PM2
pm2 start ecosystem.config.cjs

# اختبار API
curl http://localhost:3000/api/health
```

## 🎯 المهام المتبقية

### Frontend - واجهات مهمة
- ⏳ صفحة إنشاء غرفة جديدة (نموذج كامل)
- ⏳ صفحة الانضمام لغرفة (إدخال الكود)
- ⏳ واجهة غرفة اللعب التفاعلية (عرض المقاعد والأدوار)
- ⏳ لوحة تحكم المشرف/المضيف
- ⏳ واجهة الدردشة الحية
- ⏳ إشعارات في الوقت الفعلي

### تحسينات Backend
- ⏳ إضافة WebSocket للتحديثات الحية
- ⏳ نظام Admin Panel كامل
- ⏳ إحصائيات اللاعبين
- ⏳ نظام Rankings و Leaderboards

### أمان وأداء
- ⏳ Rate limiting
- ⏳ Input validation محسّن
- ⏳ Error handling أفضل
- ⏳ Caching strategy

## 🚀 النشر على Cloudflare Pages

```bash
# إنشاء قاعدة بيانات الإنتاج
npx wrangler d1 create webapp-production

# تطبيق migrations على الإنتاج
npm run db:migrate:prod

# بناء ونشر
npm run deploy:prod

# أو باستخدام wrangler مباشرة
npx wrangler pages deploy dist --project-name webapp
```

## 📖 كيفية اللعب

### قواعد اللعبة "المتوحش"

1. **البداية**: يتم اختيار متوحش سري عشوائياً
2. **مرحلة القتل**: المتوحش يختار لاعب لقتله سراً
3. **مرحلة النبض**: المشرف يعلن نبضين:
   - **نبض قريب**: مقعد قريب من المتوحش
   - **نبض بعيد**: مقعد بعيد عن المتوحش
4. **مرحلة التصويت**: جميع الأحياء يصوّتون
5. **المقعد العالي**: صاحب أعلى الأصوات يحاول:
   - كشف المتوحش (إذا صح، المتوحش يخرج وينقل دوره)
   - تحليل النبض (المتابعة للجولة القادمة)
6. **الفوز**: آخر متوحش باقٍ هو الفائز

### قواعد مهمة
- ❌ الميت صامت (لا يتكلم أو يصوت)
- ❌ ممنوع حساب النبض بصوت عالي
- ❌ ممنوع التلميح المباشر
- ✅ الكنترول فقط عبر المشرف

## 🔐 بيانات تجريبية

للاختبار، يمكنك استخدام:
- **Username**: `admin` / **Password**: `password123`
- **Username**: `player1` / **Password**: `password123`

## 📞 الدعم والمساهمة

- التطبيق حالياً في مرحلة التطوير الأولية
- المساهمات مرحب بها!

## 📝 الإصدار

- **النسخة الحالية**: 1.0.0-alpha
- **آخر تحديث**: 2025-12-24
- **الحالة**: 🟡 قيد التطوير النشط

---

**تم البناء باستخدام**: Hono + Cloudflare Workers + D1 Database + TypeScript + TailwindCSS
