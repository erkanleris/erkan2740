// ==========================================
// منصة لعبة المتوحش - Frontend Application
// ==========================================

// Global State
const state = {
    authToken: localStorage.getItem('authToken'),
    currentUser: null,
    currentRoom: null,
    currentPage: 'home',
    isAdmin: false
};

// API Base URL
const API_BASE = '';

// Axios Configuration
axios.defaults.baseURL = API_BASE;
axios.interceptors.request.use(config => {
    if (state.authToken) {
        config.headers.Authorization = `Bearer ${state.authToken}`;
    }
    return config;
});

// ==========================================
// Navigation & UI Functions
// ==========================================

function showPage(pageName) {
    console.log('Showing page:', pageName);
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    const page = document.getElementById(pageName + 'Page');
    if (page) {
        page.classList.remove('hidden');
        state.currentPage = pageName;
        
        // Load data based on page
        switch(pageName) {
            case 'dashboard':
                if (state.authToken) loadRooms();
                break;
            case 'admin':
                if (state.isAdmin) loadAdminStats();
                break;
        }
    }
}

function updateNav() {
    const navLinks = document.getElementById('navLinks');
    if (!navLinks) return;
    
    if (state.authToken && state.currentUser) {
        navLinks.innerHTML = `
            <span class="text-gray-700 dark:text-gray-300">
                <i class="fas fa-user ml-2"></i>${state.currentUser.display_name}
            </span>
            ${state.isAdmin ? `
                <button onclick="showPage('admin')" class="text-purple-600 hover:text-purple-700">
                    <i class="fas fa-shield-alt ml-2"></i>لوحة التحكم
                </button>
            ` : ''}
            <button onclick="showPage('dashboard')" class="text-blue-600 hover:text-blue-700">
                <i class="fas fa-home ml-2"></i>الرئيسية
            </button>
            <button onclick="logout()" class="btn btn-danger text-sm">
                <i class="fas fa-sign-out-alt ml-2"></i>خروج
            </button>
        `;
    } else {
        navLinks.innerHTML = `
            <button onclick="showPage('login')" class="text-gray-600 dark:text-gray-300 hover:text-blue-600">
                <i class="fas fa-sign-in-alt ml-2"></i>تسجيل الدخول
            </button>
            <button onclick="showPage('register')" class="btn btn-primary text-sm">
                <i class="fas fa-user-plus ml-2"></i>إنشاء حساب
            </button>
        `;
    }
}

function showError(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = message;
        element.classList.remove('hidden');
        setTimeout(() => element.classList.add('hidden'), 5000);
    }
}

function showSuccess(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = message;
        element.classList.remove('hidden');
        setTimeout(() => element.classList.add('hidden'), 5000);
    }
}

// ==========================================
// Authentication
// ==========================================

async function handleLogin(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    try {
        const response = await axios.post('/api/auth/login', data);
        if (response.data.success) {
            state.authToken = response.data.data.session.token;
            state.currentUser = response.data.data.user;
            state.isAdmin = response.data.data.user.is_admin === 1;
            localStorage.setItem('authToken', state.authToken);
            updateNav();
            showPage('dashboard');
        }
    } catch (error) {
        showError('loginError', error.response?.data?.error || 'خطأ في تسجيل الدخول');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    
    try {
        const response = await axios.post('/api/auth/register', data);
        if (response.data.success) {
            showSuccess('registerSuccess', 'تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول');
            setTimeout(() => showPage('login'), 2000);
        }
    } catch (error) {
        showError('registerError', error.response?.data?.error || 'خطأ في التسجيل');
    }
}

async function logout() {
    try {
        await axios.post('/api/auth/logout');
    } catch (error) {
        console.error('Logout error:', error);
    }
    
    state.authToken = null;
    state.currentUser = null;
    state.isAdmin = false;
    localStorage.removeItem('authToken');
    updateNav();
    showPage('home');
}

async function loadCurrentUser() {
    if (!state.authToken) return;
    
    try {
        const response = await axios.get('/api/auth/me');
        if (response.data.success) {
            state.currentUser = response.data.data.user;
            state.isAdmin = response.data.data.user.is_admin === 1;
            updateNav();
        }
    } catch (error) {
        console.error('Failed to load user:', error);
        logout();
    }
}

// ==========================================
// Room Management
// ==========================================

async function loadRooms() {
    try {
        const response = await axios.get('/api/rooms');
        const rooms = response.data.data.rooms;
        
        const html = rooms.length === 0 
            ? '<p class="text-gray-500 text-center py-8">لا توجد غرف متاحة حالياً</p>'
            : rooms.map(room => `
                <div class="border dark:border-gray-700 rounded-lg p-4 mb-3 hover:border-blue-500 transition">
                    <div class="flex justify-between items-center">
                        <div class="flex-1">
                            <h4 class="font-bold text-lg">
                                <i class="fas fa-door-open ml-2 text-blue-600"></i>${room.room_name}
                            </h4>
                            <div class="flex items-center gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                                <span><i class="fas fa-key ml-1"></i>الكود: <strong>${room.room_code}</strong></span>
                                <span><i class="fas fa-users ml-1"></i>اللاعبون: ${room.player_count}/${room.max_seats}</span>
                                <span><i class="fas fa-user-tie ml-1"></i>المضيف: ${room.host_name}</span>
                                <span class="px-2 py-1 rounded ${room.status === 'waiting' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}">
                                    ${room.status === 'waiting' ? 'في الانتظار' : 'جارية'}
                                </span>
                            </div>
                        </div>
                        <button onclick="joinRoomDirect('${room.room_code}')" class="btn btn-primary text-sm">
                            <i class="fas fa-sign-in-alt ml-2"></i>انضم
                        </button>
                    </div>
                </div>
            `).join('');
        
        document.getElementById('roomsList').innerHTML = html;
    } catch (error) {
        document.getElementById('roomsList').innerHTML = '<p class="text-red-500 text-center py-8">خطأ في تحميل الغرف</p>';
    }
}

async function handleCreateRoom(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    data.max_seats = parseInt(data.max_seats);
    
    try {
        const response = await axios.post('/api/rooms', data);
        if (response.data.success) {
            const room = response.data.data.room;
            showSuccess('createRoomSuccess', `تم إنشاء الغرفة! الكود: ${room.room_code}`);
            setTimeout(() => {
                showPage('dashboard');
                loadRooms();
            }, 2000);
        }
    } catch (error) {
        showError('createRoomError', error.response?.data?.error || 'خطأ في إنشاء الغرفة');
    }
}

async function handleJoinRoom(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    data.seat_number = parseInt(data.seat_number);
    
    try {
        const response = await axios.post('/api/rooms/join', data);
        if (response.data.success) {
            showSuccess('joinRoomSuccess', 'تم الانضمام للغرفة بنجاح!');
            state.currentRoom = response.data.data.room;
            setTimeout(() => loadRoomDetails(response.data.data.room.id), 1000);
        }
    } catch (error) {
        showError('joinRoomError', error.response?.data?.error || 'خطأ في الانضمام للغرفة');
    }
}

function joinRoomDirect(roomCode) {
    document.getElementById('joinRoomCode').value = roomCode;
    showPage('joinRoom');
}

async function loadRoomDetails(roomId) {
    // TODO: Implement room details page
    alert('واجهة غرفة اللعب قيد التطوير');
}

// ==========================================
// Admin Functions
// ==========================================

async function loadAdminStats() {
    try {
        const response = await axios.get('/api/admin/stats');
        if (response.data.success) {
            const stats = response.data.data;
            
            document.getElementById('totalUsers').textContent = stats.users.total;
            document.getElementById('activeUsers').textContent = stats.users.active_today;
            document.getElementById('bannedUsers').textContent = stats.users.banned;
            
            document.getElementById('totalRooms').textContent = stats.rooms.total;
            document.getElementById('activeRooms').textContent = stats.rooms.active;
            document.getElementById('waitingRooms').textContent = stats.rooms.waiting;
            document.getElementById('finishedGames').textContent = stats.rooms.finished;
            
            document.getElementById('totalMessages').textContent = stats.messages.total;
            document.getElementById('totalEvents').textContent = stats.events.total;
        }
    } catch (error) {
        console.error('Failed to load admin stats:', error);
    }
}

async function loadAdminUsers(page = 1) {
    try {
        const response = await axios.get(`/api/admin/users?page=${page}&limit=20`);
        if (response.data.success) {
            const users = response.data.data.users;
            const html = users.map(user => `
                <tr class="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td class="px-4 py-3">${user.id}</td>
                    <td class="px-4 py-3 font-medium">${user.username}</td>
                    <td class="px-4 py-3">${user.display_name}</td>
                    <td class="px-4 py-3">${user.email}</td>
                    <td class="px-4 py-3">
                        ${user.is_admin ? '<span class="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs">مشرف</span>' : ''}
                        ${user.is_banned ? '<span class="px-2 py-1 bg-red-100 text-red-700 rounded text-xs">محظور</span>' : ''}
                    </td>
                    <td class="px-4 py-3 text-sm">${new Date(user.created_at).toLocaleDateString('ar-EG')}</td>
                    <td class="px-4 py-3">
                        <button onclick="toggleBanUser(${user.id}, ${user.is_banned})" class="text-sm ${user.is_banned ? 'text-green-600' : 'text-red-600'} hover:underline ml-2">
                            <i class="fas fa-${user.is_banned ? 'check' : 'ban'} ml-1"></i>${user.is_banned ? 'إلغاء الحظر' : 'حظر'}
                        </button>
                        <button onclick="toggleAdminUser(${user.id}, ${user.is_admin})" class="text-sm ${user.is_admin ? 'text-gray-600' : 'text-purple-600'} hover:underline ml-2">
                            <i class="fas fa-shield-alt ml-1"></i>${user.is_admin ? 'إزالة المشرف' : 'جعله مشرف'}
                        </button>
                        <button onclick="deleteUser(${user.id})" class="text-sm text-red-600 hover:underline">
                            <i class="fas fa-trash ml-1"></i>حذف
                        </button>
                    </td>
                </tr>
            `).join('');
            
            document.getElementById('adminUsersTable').innerHTML = html;
        }
    } catch (error) {
        console.error('Failed to load admin users:', error);
    }
}

async function toggleBanUser(userId, currentBanned) {
    if (!confirm(`هل أنت متأكد من ${currentBanned ? 'إلغاء حظر' : 'حظر'} هذا المستخدم؟`)) return;
    
    try {
        await axios.put(`/api/admin/users/${userId}/ban`, { is_banned: !currentBanned });
        loadAdminUsers();
        loadAdminStats();
    } catch (error) {
        alert('خطأ في تحديث حالة المستخدم');
    }
}

async function toggleAdminUser(userId, currentAdmin) {
    if (!confirm(`هل أنت متأكد من ${currentAdmin ? 'إزالة صلاحيات المشرف من' : 'تعيين'} هذا المستخدم؟`)) return;
    
    try {
        await axios.put(`/api/admin/users/${userId}/admin`, { is_admin: !currentAdmin });
        loadAdminUsers();
    } catch (error) {
        alert('خطأ في تحديث صلاحيات المستخدم');
    }
}

async function deleteUser(userId) {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم نهائياً؟')) return;
    
    try {
        await axios.delete(`/api/admin/users/${userId}`);
        loadAdminUsers();
        loadAdminStats();
    } catch (error) {
        alert('خطأ في حذف المستخدم');
    }
}

async function loadAdminRooms() {
    try {
        const response = await axios.get('/api/admin/rooms');
        if (response.data.success) {
            const rooms = response.data.data.rooms;
            const html = rooms.map(room => `
                <tr class="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td class="px-4 py-3">${room.id}</td>
                    <td class="px-4 py-3 font-medium">${room.room_name}</td>
                    <td class="px-4 py-3 font-mono">${room.room_code}</td>
                    <td class="px-4 py-3">${room.host_name}</td>
                    <td class="px-4 py-3">${room.player_count}/${room.max_seats}</td>
                    <td class="px-4 py-3">
                        <span class="px-2 py-1 rounded text-xs ${
                            room.status === 'waiting' ? 'bg-green-100 text-green-700' :
                            room.status === 'playing' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-700'
                        }">${
                            room.status === 'waiting' ? 'انتظار' :
                            room.status === 'playing' ? 'جارية' : 'منتهية'
                        }</span>
                    </td>
                    <td class="px-4 py-3 text-sm">${new Date(room.created_at).toLocaleDateString('ar-EG')}</td>
                    <td class="px-4 py-3">
                        <button onclick="deleteRoom(${room.id})" class="text-sm text-red-600 hover:underline">
                            <i class="fas fa-trash ml-1"></i>حذف
                        </button>
                    </td>
                </tr>
            `).join('');
            
            document.getElementById('adminRoomsTable').innerHTML = html;
        }
    } catch (error) {
        console.error('Failed to load admin rooms:', error);
    }
}

async function deleteRoom(roomId) {
    if (!confirm('هل أنت متأكد من حذف هذه الغرفة؟')) return;
    
    try {
        await axios.delete(`/api/admin/rooms/${roomId}`);
        loadAdminRooms();
        loadAdminStats();
    } catch (error) {
        alert('خطأ في حذف الغرفة');
    }
}

async function cleanupData() {
    if (!confirm('هل أنت متأكد من تنظيف البيانات القديمة؟')) return;
    
    try {
        const response = await axios.post('/api/admin/cleanup');
        if (response.data.success) {
            alert(`تم التنظيف بنجاح!\n` +
                  `الجلسات المنتهية: ${response.data.data.expired_sessions}\n` +
                  `الغرف القديمة: ${response.data.data.old_rooms}`);
            loadAdminStats();
        }
    } catch (error) {
        alert('خطأ في التنظيف');
    }
}

// ==========================================
// Initialize
// ==========================================

document.addEventListener('DOMContentLoaded', async () => {
    console.log('App initialized');
    
    // Setup form handlers
    const loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    
    const registerForm = document.getElementById('registerForm');
    if (registerForm) registerForm.addEventListener('submit', handleRegister);
    
    const createRoomForm = document.getElementById('createRoomForm');
    if (createRoomForm) createRoomForm.addEventListener('submit', handleCreateRoom);
    
    const joinRoomForm = document.getElementById('joinRoomForm');
    if (joinRoomForm) joinRoomForm.addEventListener('submit', handleJoinRoom);
    
    // Load current user if logged in
    if (state.authToken) {
        await loadCurrentUser();
        showPage('dashboard');
    } else {
        showPage('home');
    }
});

