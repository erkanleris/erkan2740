-- ==========================================
-- بيانات تجريبية للاختبار
-- ==========================================

-- إدراج مستخدمين تجريبيين (كلمة السر: password123)
-- hash for 'password123' (هذا مثال فقط، في الإنتاج سيتم استخدام bcrypt)
INSERT OR IGNORE INTO users (username, email, password_hash, display_name, is_admin) VALUES 
  ('admin', 'admin@example.com', '$2a$10$example_hash_for_password123', 'المشرف', 1),
  ('player1', 'player1@example.com', '$2a$10$example_hash_for_password123', 'لاعب ١', 0),
  ('player2', 'player2@example.com', '$2a$10$example_hash_for_password123', 'لاعب ٢', 0),
  ('player3', 'player3@example.com', '$2a$10$example_hash_for_password123', 'لاعب ٣', 0),
  ('player4', 'player4@example.com', '$2a$10$example_hash_for_password123', 'لاعب ٤', 0),
  ('player5', 'player5@example.com', '$2a$10$example_hash_for_password123', 'لاعب ٥', 0);

-- إدراج غرفة تجريبية
INSERT OR IGNORE INTO rooms (room_code, room_name, game_type, host_user_id, max_seats, status) VALUES 
  ('TEST123', 'غرفة تجريبية', 'almutawahhish', 1, 15, 'waiting');

-- إضافة بعض الرسائل التجريبية
INSERT OR IGNORE INTO chat_messages (room_id, user_id, message_type, message_text) VALUES 
  (1, 1, 'system', 'تم إنشاء الغرفة بنجاح'),
  (1, 1, 'text', 'مرحباً بكم في لعبة المتوحش!');
