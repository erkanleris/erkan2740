-- ==========================================
-- جدول المستخدمين Users
-- ==========================================
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  is_admin INTEGER DEFAULT 0,
  is_banned INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME,
  total_games INTEGER DEFAULT 0,
  total_wins INTEGER DEFAULT 0
);

-- ==========================================
-- جدول الجلسات Sessions
-- ==========================================
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  session_token TEXT UNIQUE NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==========================================
-- جدول الغرف Rooms
-- ==========================================
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_code TEXT UNIQUE NOT NULL,
  room_name TEXT NOT NULL,
  game_type TEXT NOT NULL DEFAULT 'almutawahhish',
  host_user_id INTEGER NOT NULL,
  max_seats INTEGER NOT NULL DEFAULT 15,
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting, playing, finished
  current_round INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  started_at DATETIME,
  finished_at DATETIME,
  winner_user_id INTEGER,
  FOREIGN KEY (host_user_id) REFERENCES users(id),
  FOREIGN KEY (winner_user_id) REFERENCES users(id)
);

-- ==========================================
-- جدول اللاعبين في الغرف Room Players
-- ==========================================
CREATE TABLE IF NOT EXISTS room_players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  seat_number INTEGER NOT NULL,
  is_alive INTEGER DEFAULT 1,
  is_host INTEGER DEFAULT 0,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  killed_at DATETIME,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id),
  UNIQUE(room_id, user_id),
  UNIQUE(room_id, seat_number)
);

-- ==========================================
-- جدول الأدوار Roles
-- ==========================================
CREATE TABLE IF NOT EXISTS player_roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  role_type TEXT NOT NULL, -- mutawahhish, citizen, spectator
  is_current INTEGER DEFAULT 1,
  assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  removed_at DATETIME,
  assigned_by_user_id INTEGER, -- للمتوحش السابق الذي نقل الدور
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (assigned_by_user_id) REFERENCES users(id)
);

-- ==========================================
-- جدول الجولات Rounds
-- ==========================================
CREATE TABLE IF NOT EXISTS rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  round_number INTEGER NOT NULL,
  phase TEXT NOT NULL, -- kill, pulse, vote, high_seat
  killed_user_id INTEGER,
  near_pulse_user_id INTEGER,
  far_pulse_user_id INTEGER,
  high_seat_user_id INTEGER,
  high_seat_guess TEXT, -- reveal_mutawahhish, analyze_pulse
  high_seat_target_user_id INTEGER, -- الشخص المخمن أنه متوحش
  guess_correct INTEGER, -- 1 = صح، 0 = خطأ
  started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  ended_at DATETIME,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (killed_user_id) REFERENCES users(id),
  FOREIGN KEY (near_pulse_user_id) REFERENCES users(id),
  FOREIGN KEY (far_pulse_user_id) REFERENCES users(id),
  FOREIGN KEY (high_seat_user_id) REFERENCES users(id),
  FOREIGN KEY (high_seat_target_user_id) REFERENCES users(id),
  UNIQUE(room_id, round_number)
);

-- ==========================================
-- جدول التصويت Votes
-- ==========================================
CREATE TABLE IF NOT EXISTS votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  round_id INTEGER NOT NULL,
  voter_user_id INTEGER NOT NULL,
  voted_for_user_id INTEGER NOT NULL,
  voted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (round_id) REFERENCES rounds(id) ON DELETE CASCADE,
  FOREIGN KEY (voter_user_id) REFERENCES users(id),
  FOREIGN KEY (voted_for_user_id) REFERENCES users(id),
  UNIQUE(round_id, voter_user_id)
);

-- ==========================================
-- جدول الرسائل Chat Messages
-- ==========================================
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  message_type TEXT NOT NULL DEFAULT 'text', -- text, system, announcement
  message_text TEXT NOT NULL,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==========================================
-- جدول سجل الأحداث Game Events Log
-- ==========================================
CREATE TABLE IF NOT EXISTS game_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  round_id INTEGER,
  event_type TEXT NOT NULL, -- game_start, player_join, player_kill, pulse_announce, vote_cast, high_seat, role_transfer, game_end
  event_data TEXT, -- JSON data
  user_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (round_id) REFERENCES rounds(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==========================================
-- الفهارس Indexes
-- ==========================================
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

CREATE INDEX IF NOT EXISTS idx_rooms_code ON rooms(room_code);
CREATE INDEX IF NOT EXISTS idx_rooms_host ON rooms(host_user_id);
CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);

CREATE INDEX IF NOT EXISTS idx_room_players_room ON room_players(room_id);
CREATE INDEX IF NOT EXISTS idx_room_players_user ON room_players(user_id);
CREATE INDEX IF NOT EXISTS idx_room_players_alive ON room_players(is_alive);

CREATE INDEX IF NOT EXISTS idx_player_roles_room ON player_roles(room_id);
CREATE INDEX IF NOT EXISTS idx_player_roles_user ON player_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_player_roles_current ON player_roles(is_current);

CREATE INDEX IF NOT EXISTS idx_rounds_room ON rounds(room_id);
CREATE INDEX IF NOT EXISTS idx_rounds_number ON rounds(round_number);

CREATE INDEX IF NOT EXISTS idx_votes_round ON votes(round_id);
CREATE INDEX IF NOT EXISTS idx_votes_voter ON votes(voter_user_id);

CREATE INDEX IF NOT EXISTS idx_chat_room ON chat_messages(room_id);
CREATE INDEX IF NOT EXISTS idx_chat_time ON chat_messages(sent_at);

CREATE INDEX IF NOT EXISTS idx_events_room ON game_events(room_id);
CREATE INDEX IF NOT EXISTS idx_events_round ON game_events(round_id);
CREATE INDEX IF NOT EXISTS idx_events_type ON game_events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_time ON game_events(created_at);
