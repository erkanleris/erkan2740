import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { serveStatic } from 'hono/cloudflare-workers';
import { Env } from './types';

// Import routes
import authRoutes from './routes/auth';
import roomRoutes from './routes/rooms';
import gameRoutes from './routes/game';
import voteRoutes from './routes/vote';
import chatRoutes from './routes/chat';
import adminRoutes from './routes/admin';

const app = new Hono<{ Bindings: Env }>();

// Enable CORS for API routes
app.use('/api/*', cors());

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }));

// API Routes
app.route('/api/auth', authRoutes);
app.route('/api/rooms', roomRoutes);
app.route('/api/game', gameRoutes);
app.route('/api/vote', voteRoutes);
app.route('/api/chat', chatRoutes);
app.route('/api/admin', adminRoutes);

// Health check endpoint
app.get('/api/health', (c) => {
  return c.json({ 
    success: true, 
    message: 'API is running',
    timestamp: new Date().toISOString()
  });
});

// Serve index.html for all other routes
app.get('*', serveStatic({ path: './public/index.html' }));

export default app;
