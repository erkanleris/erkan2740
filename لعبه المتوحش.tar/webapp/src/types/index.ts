// ==========================================
// TypeScript Types & Interfaces
// ==========================================

export type D1Database = any;

export interface Env {
  DB: D1Database;
}

// ==========================================
// User Types
// ==========================================
export interface User {
  id: number;
  username: string;
  email: string;
  password_hash: string;
  display_name: string;
  is_admin: number;
  is_banned: number;
  created_at: string;
  last_login: string | null;
  total_games: number;
  total_wins: number;
}

export interface Session {
  id: number;
  user_id: number;
  session_token: string;
  expires_at: string;
  created_at: string;
}

// ==========================================
// Room Types
// ==========================================
export type RoomStatus = 'waiting' | 'playing' | 'finished';
export type GameType = 'almutawahhish';

export interface Room {
  id: number;
  room_code: string;
  room_name: string;
  game_type: GameType;
  host_user_id: number;
  max_seats: number;
  status: RoomStatus;
  current_round: number;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
  winner_user_id: number | null;
}

export interface RoomPlayer {
  id: number;
  room_id: number;
  user_id: number;
  seat_number: number;
  is_alive: number;
  is_host: number;
  joined_at: string;
  killed_at: string | null;
}

// ==========================================
// Role Types
// ==========================================
export type RoleType = 'mutawahhish' | 'citizen' | 'spectator';

export interface PlayerRole {
  id: number;
  room_id: number;
  user_id: number;
  role_type: RoleType;
  is_current: number;
  assigned_at: string;
  removed_at: string | null;
  assigned_by_user_id: number | null;
}

// ==========================================
// Round Types
// ==========================================
export type RoundPhase = 'kill' | 'pulse' | 'vote' | 'high_seat';

export interface Round {
  id: number;
  room_id: number;
  round_number: number;
  phase: RoundPhase;
  killed_user_id: number | null;
  near_pulse_user_id: number | null;
  far_pulse_user_id: number | null;
  high_seat_user_id: number | null;
  high_seat_guess: string | null;
  high_seat_target_user_id: number | null;
  guess_correct: number | null;
  started_at: string;
  ended_at: string | null;
}

export interface Vote {
  id: number;
  round_id: number;
  voter_user_id: number;
  voted_for_user_id: number;
  voted_at: string;
}

// ==========================================
// Chat & Events Types
// ==========================================
export type MessageType = 'text' | 'system' | 'announcement';

export interface ChatMessage {
  id: number;
  room_id: number;
  user_id: number;
  message_type: MessageType;
  message_text: string;
  sent_at: string;
}

export type EventType = 
  | 'game_start'
  | 'player_join'
  | 'player_kill'
  | 'pulse_announce'
  | 'vote_cast'
  | 'high_seat'
  | 'role_transfer'
  | 'game_end';

export interface GameEvent {
  id: number;
  room_id: number;
  round_id: number | null;
  event_type: EventType;
  event_data: string | null;
  user_id: number | null;
  created_at: string;
}

// ==========================================
// API Response Types
// ==========================================
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  total: number;
  page: number;
  pageSize: number;
}

// ==========================================
// Request Body Types
// ==========================================
export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  display_name: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface CreateRoomRequest {
  room_name: string;
  max_seats: number;
  game_type: GameType;
}

export interface JoinRoomRequest {
  room_code: string;
  seat_number: number;
}

export interface KillPlayerRequest {
  target_user_id: number;
}

export interface SelectPulseRequest {
  near_pulse_user_id: number;
  far_pulse_user_id: number;
}

export interface CastVoteRequest {
  voted_for_user_id: number;
}

export interface HighSeatGuessRequest {
  guess_type: 'reveal_mutawahhish' | 'analyze_pulse';
  target_user_id?: number; // مطلوب فقط إذا كان guess_type = reveal_mutawahhish
}

export interface TransferRoleRequest {
  new_mutawahhish_user_id: number;
}

export interface SendMessageRequest {
  message_text: string;
}
