// ==========================================
// Authentication & Security Utilities
// ==========================================

/**
 * توليد رمز عشوائي آمن
 */
export function generateToken(length: number = 32): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * توليد كود غرفة عشوائي
 */
export function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // بدون أحرف ملتبسة
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

/**
 * تشفير كلمة المرور (باستخدام Web Crypto API)
 * ملاحظة: في Cloudflare Workers، نستخدم Web Crypto API بدلاً من bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * التحقق من كلمة المرور
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const passwordHash = await hashPassword(password);
  return passwordHash === hash;
}

/**
 * توليد تاريخ انتهاء الجلسة (7 أيام من الآن)
 */
export function generateSessionExpiry(): string {
  const now = new Date();
  now.setDate(now.getDate() + 7);
  return now.toISOString();
}

/**
 * التحقق من صلاحية الجلسة
 */
export function isSessionValid(expiresAt: string): boolean {
  const now = new Date();
  const expiry = new Date(expiresAt);
  return expiry > now;
}

/**
 * استخراج رمز الجلسة من header
 */
export function extractSessionToken(authHeader: string | null): string | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  return authHeader.substring(7);
}

/**
 * التحقق من صحة البريد الإلكتروني
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * التحقق من صحة اسم المستخدم
 */
export function isValidUsername(username: string): boolean {
  // 3-20 حرف، حروف وأرقام و_ فقط
  const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
  return usernameRegex.test(username);
}

/**
 * التحقق من قوة كلمة المرور
 */
export function isStrongPassword(password: string): boolean {
  // على الأقل 8 أحرف
  return password.length >= 8;
}
