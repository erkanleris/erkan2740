// ==========================================
// Game Logic Utilities
// ==========================================

import { RoomPlayer } from '../types';

/**
 * حساب المسافة بين مقعدين في ترتيب دائري
 */
export function calculateDistance(seat1: number, seat2: number, totalSeats: number): number {
  const diff = Math.abs(seat1 - seat2);
  return Math.min(diff, totalSeats - diff);
}

/**
 * العثور على أقرب لاعب حي من المتوحش
 */
export function findNearestPlayer(
  mutawahhishSeat: number, 
  alivePlayers: RoomPlayer[], 
  totalSeats: number
): RoomPlayer | null {
  if (alivePlayers.length === 0) return null;
  
  // تصفية اللاعبين لإزالة المتوحش نفسه
  const otherPlayers = alivePlayers.filter(p => p.seat_number !== mutawahhishSeat);
  if (otherPlayers.length === 0) return null;
  
  let nearest = otherPlayers[0];
  let minDistance = calculateDistance(mutawahhishSeat, nearest.seat_number, totalSeats);
  
  for (const player of otherPlayers) {
    const distance = calculateDistance(mutawahhishSeat, player.seat_number, totalSeats);
    if (distance < minDistance) {
      minDistance = distance;
      nearest = player;
    }
  }
  
  return nearest;
}

/**
 * العثور على أبعد لاعب حي من المتوحش
 */
export function findFarthestPlayer(
  mutawahhishSeat: number, 
  alivePlayers: RoomPlayer[], 
  totalSeats: number
): RoomPlayer | null {
  if (alivePlayers.length === 0) return null;
  
  // تصفية اللاعبين لإزالة المتوحش نفسه
  const otherPlayers = alivePlayers.filter(p => p.seat_number !== mutawahhishSeat);
  if (otherPlayers.length === 0) return null;
  
  let farthest = otherPlayers[0];
  let maxDistance = calculateDistance(mutawahhishSeat, farthest.seat_number, totalSeats);
  
  for (const player of otherPlayers) {
    const distance = calculateDistance(mutawahhishSeat, player.seat_number, totalSeats);
    if (distance > maxDistance) {
      maxDistance = distance;
      farthest = player;
    }
  }
  
  return farthest;
}

/**
 * اختيار نبضين (قريب وبعيد) بناءً على موقع المتوحش
 */
export function selectPulses(
  mutawahhishSeat: number,
  alivePlayers: RoomPlayer[],
  totalSeats: number
): { near: RoomPlayer | null; far: RoomPlayer | null } {
  const near = findNearestPlayer(mutawahhishSeat, alivePlayers, totalSeats);
  const far = findFarthestPlayer(mutawahhishSeat, alivePlayers, totalSeats);
  
  return { near, far };
}

/**
 * حساب نتائج التصويت
 */
export interface VoteResult {
  user_id: number;
  vote_count: number;
  seat_number?: number;
}

export function calculateVoteResults(votes: { voted_for_user_id: number }[]): VoteResult[] {
  const voteCounts = new Map<number, number>();
  
  for (const vote of votes) {
    const current = voteCounts.get(vote.voted_for_user_id) || 0;
    voteCounts.set(vote.voted_for_user_id, current + 1);
  }
  
  const results: VoteResult[] = [];
  voteCounts.forEach((count, userId) => {
    results.push({ user_id: userId, vote_count: count });
  });
  
  // ترتيب حسب عدد الأصوات (من الأكثر إلى الأقل)
  results.sort((a, b) => b.vote_count - a.vote_count);
  
  return results;
}

/**
 * الحصول على اللاعب صاحب أعلى الأصوات
 */
export function getHighestVotedPlayer(votes: { voted_for_user_id: number }[]): number | null {
  if (votes.length === 0) return null;
  
  const results = calculateVoteResults(votes);
  return results[0]?.user_id || null;
}

/**
 * التحقق من فوز اللعبة (متوحش واحد متبقي فقط)
 */
export function checkGameWin(
  alivePlayers: RoomPlayer[],
  activeMutawahhishIds: number[]
): { isGameOver: boolean; winnerId: number | null } {
  // إذا كان هناك متوحش واحد فقط متبقي وباقي اللاعبين ماتوا
  const aliveMutawahhish = alivePlayers.filter(p => 
    activeMutawahhishIds.includes(p.user_id)
  );
  
  if (aliveMutawahhish.length === 1 && alivePlayers.length === 1) {
    return { isGameOver: true, winnerId: aliveMutawahhish[0].user_id };
  }
  
  // إذا لم يتبق أي متوحش
  if (aliveMutawahhish.length === 0) {
    return { isGameOver: true, winnerId: null };
  }
  
  return { isGameOver: false, winnerId: null };
}

/**
 * اختيار لاعب عشوائي لدور المتوحش
 */
export function selectRandomMutawahhish(players: RoomPlayer[]): RoomPlayer | null {
  if (players.length === 0) return null;
  const randomIndex = Math.floor(Math.random() * players.length);
  return players[randomIndex];
}

/**
 * التحقق من صحة اختيار النبض (يجب أن يكونوا مختلفين وأحياء)
 */
export function validatePulseSelection(
  nearUserId: number,
  farUserId: number,
  alivePlayers: RoomPlayer[]
): { valid: boolean; error?: string } {
  if (nearUserId === farUserId) {
    return { valid: false, error: 'يجب أن يكون النبضان مختلفين' };
  }
  
  const nearPlayer = alivePlayers.find(p => p.user_id === nearUserId);
  const farPlayer = alivePlayers.find(p => p.user_id === farUserId);
  
  if (!nearPlayer || !farPlayer) {
    return { valid: false, error: 'أحد اللاعبين المختارين غير موجود أو ميت' };
  }
  
  return { valid: true };
}
