// ==========================================
// Authentication Middleware
// ==========================================

import { Context, Next } from 'hono';
import { Env, Session, User } from '../types';
import { extractSessionToken, isSessionValid } from '../utils/auth';

/**
 * توسيع Context لإضافة user
 */
export interface AuthContext extends Context {
  env: Env;
  user?: User;
  session?: Session;
}

/**
 * Middleware للتحقق من المصادقة
 */
export async function authMiddleware(c: Context, next: Next) {
  const authHeader = c.req.header('Authorization');
  const sessionToken = extractSessionToken(authHeader);
  
  if (!sessionToken) {
    return c.json({ success: false, error: 'غير مصرح - يجب تسجيل الدخول' }, 401);
  }
  
  try {
    // البحث عن الجلسة
    const session = await c.env.DB.prepare(`
      SELECT * FROM sessions 
      WHERE session_token = ? 
      LIMIT 1
    `).bind(sessionToken).first() as Session | null;
    
    if (!session) {
      return c.json({ success: false, error: 'جلسة غير صالحة' }, 401);
    }
    
    // التحقق من انتهاء الجلسة
    if (!isSessionValid(session.expires_at)) {
      return c.json({ success: false, error: 'انتهت صلاحية الجلسة' }, 401);
    }
    
    // البحث عن المستخدم
    const user = await c.env.DB.prepare(`
      SELECT * FROM users 
      WHERE id = ? 
      LIMIT 1
    `).bind(session.user_id).first() as User | null;
    
    if (!user) {
      return c.json({ success: false, error: 'مستخدم غير موجود' }, 401);
    }
    
    // التحقق من حظر المستخدم
    if (user.is_banned) {
      return c.json({ success: false, error: 'تم حظر هذا المستخدم' }, 403);
    }
    
    // إضافة المستخدم والجلسة إلى Context
    c.set('user', user);
    c.set('session', session);
    
    await next();
  } catch (error: any) {
    return c.json({ 
      success: false, 
      error: 'خطأ في التحقق من المصادقة',
      details: error.message 
    }, 500);
  }
}

/**
 * Middleware للتحقق من أن المستخدم هو المشرف
 */
export async function adminMiddleware(c: Context, next: Next) {
  const user = c.get('user') as User | undefined;
  
  if (!user) {
    return c.json({ success: false, error: 'غير مصرح' }, 401);
  }
  
  if (!user.is_admin) {
    return c.json({ success: false, error: 'يجب أن تكون مشرفاً للوصول' }, 403);
  }
  
  await next();
}

/**
 * Middleware للتحقق من أن المستخدم هو مضيف الغرفة
 */
export async function roomHostMiddleware(c: Context, next: Next) {
  const user = c.get('user') as User | undefined;
  const roomId = c.req.param('roomId');
  
  if (!user) {
    return c.json({ success: false, error: 'غير مصرح' }, 401);
  }
  
  try {
    const room = await c.env.DB.prepare(`
      SELECT * FROM rooms WHERE id = ? LIMIT 1
    `).bind(roomId).first();
    
    if (!room) {
      return c.json({ success: false, error: 'الغرفة غير موجودة' }, 404);
    }
    
    if (room.host_user_id !== user.id && !user.is_admin) {
      return c.json({ success: false, error: 'يجب أن تكون مضيف الغرفة' }, 403);
    }
    
    await next();
  } catch (error: any) {
    return c.json({ 
      success: false, 
      error: 'خطأ في التحقق من صلاحيات الغرفة',
      details: error.message 
    }, 500);
  }
}

/**
 * Middleware اختياري للمصادقة (لا يرفض الطلب إذا لم يكن مصادقاً)
 */
export async function optionalAuthMiddleware(c: Context, next: Next) {
  const authHeader = c.req.header('Authorization');
  const sessionToken = extractSessionToken(authHeader);
  
  if (sessionToken) {
    try {
      const session = await c.env.DB.prepare(`
        SELECT * FROM sessions 
        WHERE session_token = ? 
        LIMIT 1
      `).bind(sessionToken).first() as Session | null;
      
      if (session && isSessionValid(session.expires_at)) {
        const user = await c.env.DB.prepare(`
          SELECT * FROM users 
          WHERE id = ? 
          LIMIT 1
        `).bind(session.user_id).first() as User | null;
        
        if (user && !user.is_banned) {
          c.set('user', user);
          c.set('session', session);
        }
      }
    } catch (error) {
      // تجاهل الأخطاء في المصادقة الاختيارية
    }
  }
  
  await next();
}
