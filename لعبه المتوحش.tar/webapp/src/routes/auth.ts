// ==========================================
// Authentication Routes
// ==========================================

import { Hono } from 'hono';
import { Env, User, RegisterRequest, LoginRequest, ApiResponse } from '../types';
import { 
  hashPassword, 
  verifyPassword, 
  generateToken, 
  generateSessionExpiry,
  isValidEmail,
  isValidUsername,
  isStrongPassword
} from '../utils/auth';

const authRoutes = new Hono<{ Bindings: Env }>();

/**
 * POST /api/auth/register
 * تسجيل مستخدم جديد
 */
authRoutes.post('/register', async (c) => {
  try {
    const body: RegisterRequest = await c.req.json();
    const { username, email, password, display_name } = body;
    
    // التحقق من صحة البيانات
    if (!username || !email || !password || !display_name) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'جميع الحقول مطلوبة' 
      }, 400);
    }
    
    // التحقق من صحة البريد الإلكتروني
    if (!isValidEmail(email)) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'البريد الإلكتروني غير صالح' 
      }, 400);
    }
    
    // التحقق من صحة اسم المستخدم
    if (!isValidUsername(username)) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم المستخدم يجب أن يكون 3-20 حرف ويحتوي على حروف وأرقام و_ فقط' 
      }, 400);
    }
    
    // التحقق من قوة كلمة المرور
    if (!isStrongPassword(password)) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' 
      }, 400);
    }
    
    // التحقق من عدم وجود المستخدم مسبقاً
    const existingUser = await c.env.DB.prepare(`
      SELECT id FROM users 
      WHERE username = ? OR email = ? 
      LIMIT 1
    `).bind(username, email).first();
    
    if (existingUser) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل' 
      }, 409);
    }
    
    // تشفير كلمة المرور
    const passwordHash = await hashPassword(password);
    
    // إدراج المستخدم الجديد
    const result = await c.env.DB.prepare(`
      INSERT INTO users (username, email, password_hash, display_name)
      VALUES (?, ?, ?, ?)
    `).bind(username, email, passwordHash, display_name).run();
    
    if (!result.success) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'فشل في إنشاء المستخدم' 
      }, 500);
    }
    
    return c.json<ApiResponse>({ 
      success: true, 
      message: 'تم التسجيل بنجاح',
      data: {
        username,
        email,
        display_name
      }
    }, 201);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في التسجيل',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/auth/login
 * تسجيل الدخول
 */
authRoutes.post('/login', async (c) => {
  try {
    const body: LoginRequest = await c.req.json();
    const { username, password } = body;
    
    // التحقق من صحة البيانات
    if (!username || !password) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم المستخدم وكلمة المرور مطلوبان' 
      }, 400);
    }
    
    // البحث عن المستخدم
    const user = await c.env.DB.prepare(`
      SELECT * FROM users 
      WHERE username = ? 
      LIMIT 1
    `).bind(username).first() as User | null;
    
    if (!user) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم المستخدم أو كلمة المرور غير صحيحة' 
      }, 401);
    }
    
    // التحقق من حظر المستخدم
    if (user.is_banned) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'تم حظر هذا المستخدم' 
      }, 403);
    }
    
    // التحقق من كلمة المرور
    const isPasswordValid = await verifyPassword(password, user.password_hash);
    
    if (!isPasswordValid) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم المستخدم أو كلمة المرور غير صحيحة' 
      }, 401);
    }
    
    // إنشاء جلسة جديدة
    const sessionToken = generateToken();
    const expiresAt = generateSessionExpiry();
    
    await c.env.DB.prepare(`
      INSERT INTO sessions (user_id, session_token, expires_at)
      VALUES (?, ?, ?)
    `).bind(user.id, sessionToken, expiresAt).run();
    
    // تحديث آخر تسجيل دخول
    await c.env.DB.prepare(`
      UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
    `).bind(user.id).run();
    
    // إرجاع البيانات (بدون password_hash)
    const { password_hash, ...userWithoutPassword } = user;
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم تسجيل الدخول بنجاح',
      data: {
        user: userWithoutPassword,
        session: {
          token: sessionToken,
          expires_at: expiresAt
        }
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في تسجيل الدخول',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/auth/logout
 * تسجيل الخروج
 */
authRoutes.post('/logout', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'رمز الجلسة مطلوب' 
      }, 400);
    }
    
    const sessionToken = authHeader.substring(7);
    
    // حذف الجلسة
    await c.env.DB.prepare(`
      DELETE FROM sessions WHERE session_token = ?
    `).bind(sessionToken).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم تسجيل الخروج بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في تسجيل الخروج',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/auth/me
 * الحصول على بيانات المستخدم الحالي
 */
authRoutes.get('/me', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'رمز الجلسة مطلوب' 
      }, 401);
    }
    
    const sessionToken = authHeader.substring(7);
    
    // البحث عن الجلسة
    const session = await c.env.DB.prepare(`
      SELECT * FROM sessions WHERE session_token = ? LIMIT 1
    `).bind(sessionToken).first();
    
    if (!session) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'جلسة غير صالحة' 
      }, 401);
    }
    
    // البحث عن المستخدم
    const user = await c.env.DB.prepare(`
      SELECT id, username, email, display_name, is_admin, is_banned, 
             created_at, last_login, total_games, total_wins
      FROM users WHERE id = ? LIMIT 1
    `).bind(session.user_id).first();
    
    if (!user) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'مستخدم غير موجود' 
      }, 404);
    }
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { user }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب بيانات المستخدم',
      message: error.message 
    }, 500);
  }
});

export default authRoutes;
