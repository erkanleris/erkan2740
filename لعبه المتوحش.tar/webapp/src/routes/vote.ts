// ==========================================
// Vote & High Seat Routes
// ==========================================

import { Hono } from 'hono';
import { Env, ApiResponse, User, Room, Round, Vote, RoomPlayer, PlayerRole } from '../types';
import { authMiddleware, roomHostMiddleware } from '../middleware/auth';
import { getHighestVotedPlayer, checkGameWin } from '../utils/game';

const voteRoutes = new Hono<{ Bindings: Env }>();

// تطبيق middleware المصادقة
voteRoutes.use('/*', authMiddleware);

/**
 * POST /api/vote/:roomId/cast
 * التصويت (اللاعبون الأحياء فقط)
 */
voteRoutes.post('/:roomId/cast', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    const { voted_for_user_id } = await c.req.json();
    
    // التحقق من أن اللاعب حي
    const player = await c.env.DB.prepare(`
      SELECT * FROM room_players 
      WHERE room_id = ? AND user_id = ? AND is_alive = 1
      LIMIT 1
    `).bind(roomId, user.id).first() as RoomPlayer | null;
    
    if (!player) {
      return c.json<ApiResponse>({ success: false, error: 'اللاعبون الميتون لا يمكنهم التصويت' }, 403);
    }
    
    // جلب الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (!round || round.phase !== 'vote') {
      return c.json<ApiResponse>({ success: false, error: 'ليس وقت التصويت الآن' }, 400);
    }
    
    // التحقق من أن الهدف حي
    const targetPlayer = await c.env.DB.prepare(`
      SELECT * FROM room_players 
      WHERE room_id = ? AND user_id = ? AND is_alive = 1
      LIMIT 1
    `).bind(roomId, voted_for_user_id).first();
    
    if (!targetPlayer) {
      return c.json<ApiResponse>({ success: false, error: 'لا يمكن التصويت للاعب ميت' }, 400);
    }
    
    // التحقق من عدم التصويت مسبقاً
    const existingVote = await c.env.DB.prepare(`
      SELECT id FROM votes WHERE round_id = ? AND voter_user_id = ? LIMIT 1
    `).bind(round.id, user.id).first();
    
    if (existingVote) {
      return c.json<ApiResponse>({ success: false, error: 'لقد صوّت بالفعل في هذه الجولة' }, 400);
    }
    
    // تسجيل الصوت
    await c.env.DB.prepare(`
      INSERT INTO votes (round_id, voter_user_id, voted_for_user_id)
      VALUES (?, ?, ?)
    `).bind(round.id, user.id, voted_for_user_id).run();
    
    // تسجيل حدث التصويت
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, round_id, event_type, event_data, user_id)
      VALUES (?, ?, 'vote_cast', ?, ?)
    `).bind(roomId, round.id, JSON.stringify({ voted_for_user_id }), user.id).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم تسجيل صوتك بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في التصويت',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/vote/:roomId/finalize
 * إنهاء التصويت وتحديد المقعد العالي (المضيف فقط)
 */
voteRoutes.post('/:roomId/finalize', roomHostMiddleware, async (c) => {
  try {
    const roomId = c.req.param('roomId');
    
    // جلب الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (!round || round.phase !== 'vote') {
      return c.json<ApiResponse>({ success: false, error: 'ليس وقت إنهاء التصويت الآن' }, 400);
    }
    
    // جلب الأصوات
    const votes = await c.env.DB.prepare(`
      SELECT * FROM votes WHERE round_id = ?
    `).bind(round.id).all();
    
    const voteList = votes.results as Vote[];
    
    if (voteList.length === 0) {
      return c.json<ApiResponse>({ success: false, error: 'لا توجد أصوات بعد' }, 400);
    }
    
    // حساب صاحب أعلى الأصوات
    const highestVotedUserId = getHighestVotedPlayer(voteList);
    
    if (!highestVotedUserId) {
      return c.json<ApiResponse>({ success: false, error: 'فشل في حساب النتائج' }, 500);
    }
    
    // تحديث الجولة
    await c.env.DB.prepare(`
      UPDATE rounds 
      SET high_seat_user_id = ?, phase = 'high_seat'
      WHERE id = ?
    `).bind(highestVotedUserId, round.id).run();
    
    // رسالة نظام
    const highSeatUser = await c.env.DB.prepare(`
      SELECT u.display_name, rp.seat_number 
      FROM users u 
      JOIN room_players rp ON u.id = rp.user_id 
      WHERE u.id = ? AND rp.room_id = ? 
      LIMIT 1
    `).bind(highestVotedUserId, roomId).first();
    
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, 1, 'announcement', ?)
    `).bind(
      roomId, 
      `المقعد العالي: ${highSeatUser?.seat_number} - ${highSeatUser?.display_name}`
    ).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم تحديد المقعد العالي',
      data: { 
        high_seat_user_id: highestVotedUserId,
        next_phase: 'high_seat'
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في إنهاء التصويت',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/vote/:roomId/high-seat-guess
 * صاحب المقعد العالي يحاول كشف المتوحش أو تحليل النبض
 */
voteRoutes.post('/:roomId/high-seat-guess', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    const { guess_type, target_user_id } = await c.req.json();
    
    // جلب الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (!round || round.phase !== 'high_seat') {
      return c.json<ApiResponse>({ success: false, error: 'ليس وقت المقعد العالي الآن' }, 400);
    }
    
    if (round.high_seat_user_id !== user.id) {
      return c.json<ApiResponse>({ success: false, error: 'أنت لست صاحب المقعد العالي' }, 403);
    }
    
    let guessCorrect = 0;
    let shouldKillPlayer = false;
    let shouldTransferRole = false;
    let messageText = '';
    
    if (guess_type === 'reveal_mutawahhish') {
      if (!target_user_id) {
        return c.json<ApiResponse>({ success: false, error: 'يجب تحديد اللاعب المستهدف' }, 400);
      }
      
      // التحقق من أن الهدف هو المتوحش
      const targetRole = await c.env.DB.prepare(`
        SELECT * FROM player_roles 
        WHERE room_id = ? AND user_id = ? AND is_current = 1 AND role_type = 'mutawahhish'
        LIMIT 1
      `).bind(roomId, target_user_id).first();
      
      if (targetRole) {
        // التخمين صحيح!
        guessCorrect = 1;
        shouldTransferRole = true;
        messageText = 'تخمين صحيح! تم كشف المتوحش';
      } else {
        // التخمين خاطئ
        guessCorrect = 0;
        shouldKillPlayer = true;
        messageText = 'تخمين خاطئ! سيتم إخراجك من اللعبة';
      }
      
    } else if (guess_type === 'analyze_pulse') {
      // تحليل النبض - دائماً "خطأ" حسب قواعد اللعبة
      guessCorrect = 0;
      shouldKillPlayer = true;
      messageText = 'تم اختيار تحليل النبض - سيتم المتابعة للجولة القادمة';
    } else {
      return c.json<ApiResponse>({ success: false, error: 'نوع التخمين غير صالح' }, 400);
    }
    
    // تحديث الجولة
    await c.env.DB.prepare(`
      UPDATE rounds 
      SET high_seat_guess = ?, high_seat_target_user_id = ?, guess_correct = ?
      WHERE id = ?
    `).bind(guess_type, target_user_id || null, guessCorrect, round.id).run();
    
    // إذا كان التخمين خاطئ، قتل صاحب المقعد العالي
    if (shouldKillPlayer) {
      await c.env.DB.prepare(`
        UPDATE room_players 
        SET is_alive = 0, killed_at = CURRENT_TIMESTAMP
        WHERE room_id = ? AND user_id = ?
      `).bind(roomId, user.id).run();
      
      // إزالة دوره إذا كان متوحشاً
      await c.env.DB.prepare(`
        UPDATE player_roles 
        SET is_current = 0, removed_at = CURRENT_TIMESTAMP
        WHERE room_id = ? AND user_id = ? AND is_current = 1
      `).bind(roomId, user.id).run();
    }
    
    // إذا كان التخمين صحيح، نقل دور المتوحش
    if (shouldTransferRole) {
      // إزالة دور المتوحش القديم
      await c.env.DB.prepare(`
        UPDATE player_roles 
        SET is_current = 0, removed_at = CURRENT_TIMESTAMP
        WHERE room_id = ? AND user_id = ? AND is_current = 1 AND role_type = 'mutawahhish'
      `).bind(roomId, target_user_id).run();
      
      // قتل المتوحش القديم
      await c.env.DB.prepare(`
        UPDATE room_players 
        SET is_alive = 0, killed_at = CURRENT_TIMESTAMP
        WHERE room_id = ? AND user_id = ?
      `).bind(roomId, target_user_id).run();
      
      // ملاحظة: المتوحش القديم سيختار متوحش جديد عبر endpoint منفصل
      messageText += ' - يجب على المتوحش القديم اختيار متوحش جديد';
    }
    
    // تسجيل الحدث
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, round_id, event_type, event_data, user_id)
      VALUES (?, ?, 'high_seat', ?, ?)
    `).bind(roomId, round.id, JSON.stringify({ 
      guess_type, 
      target_user_id, 
      guess_correct: guessCorrect 
    }), user.id).run();
    
    // رسالة نظام
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, 1, 'announcement', ?)
    `).bind(roomId, messageText).run();
    
    // إنهاء الجولة إذا لم يكن هناك نقل دور
    if (!shouldTransferRole) {
      await c.env.DB.prepare(`
        UPDATE rounds SET ended_at = CURRENT_TIMESTAMP WHERE id = ?
      `).bind(round.id).run();
      
      // التحقق من فوز اللعبة
      const alivePlayers = await c.env.DB.prepare(`
        SELECT * FROM room_players WHERE room_id = ? AND is_alive = 1
      `).bind(roomId).all();
      
      const activeMutawahhish = await c.env.DB.prepare(`
        SELECT user_id FROM player_roles 
        WHERE room_id = ? AND is_current = 1 AND role_type = 'mutawahhish'
      `).bind(roomId).all();
      
      const mutawahhishIds = (activeMutawahhish.results as PlayerRole[]).map(r => r.user_id);
      const { isGameOver, winnerId } = checkGameWin(
        alivePlayers.results as RoomPlayer[], 
        mutawahhishIds
      );
      
      if (isGameOver) {
        await c.env.DB.prepare(`
          UPDATE rooms 
          SET status = 'finished', finished_at = CURRENT_TIMESTAMP, winner_user_id = ?
          WHERE id = ?
        `).bind(winnerId, roomId).run();
        
        await c.env.DB.prepare(`
          INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
          VALUES (?, 1, 'announcement', 'انتهت اللعبة!')
        `).bind(roomId).run();
        
        return c.json<ApiResponse>({ 
          success: true,
          message: 'انتهت اللعبة!',
          data: { game_over: true, winner_id: winnerId }
        }, 200);
      }
      
      // بدء جولة جديدة
      const newRoundNumber = round.round_number + 1;
      await c.env.DB.prepare(`
        INSERT INTO rounds (room_id, round_number, phase)
        VALUES (?, ?, 'kill')
      `).bind(roomId, newRoundNumber).run();
      
      await c.env.DB.prepare(`
        UPDATE rooms SET current_round = ? WHERE id = ?
      `).bind(newRoundNumber, roomId).run();
    }
    
    return c.json<ApiResponse>({ 
      success: true,
      message: messageText,
      data: { 
        guess_correct: guessCorrect,
        requires_role_transfer: shouldTransferRole
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في تخمين المقعد العالي',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/vote/:roomId/transfer-role
 * المتوحش القديم ينقل الدور لمتوحش جديد
 */
voteRoutes.post('/:roomId/transfer-role', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    const { new_mutawahhish_user_id } = await c.req.json();
    
    // التحقق من أن المستخدم كان متوحشاً سابقاً
    const oldRole = await c.env.DB.prepare(`
      SELECT * FROM player_roles 
      WHERE room_id = ? AND user_id = ? AND role_type = 'mutawahhish'
      ORDER BY assigned_at DESC
      LIMIT 1
    `).bind(roomId, user.id).first() as PlayerRole | null;
    
    if (!oldRole) {
      return c.json<ApiResponse>({ success: false, error: 'أنت لست متوحشاً' }, 403);
    }
    
    // التحقق من أن اللاعب الجديد حي
    const newPlayer = await c.env.DB.prepare(`
      SELECT * FROM room_players 
      WHERE room_id = ? AND user_id = ? AND is_alive = 1
      LIMIT 1
    `).bind(roomId, new_mutawahhish_user_id).first();
    
    if (!newPlayer) {
      return c.json<ApiResponse>({ success: false, error: 'اللاعب المختار ميت أو غير موجود' }, 400);
    }
    
    // إزالة دور المواطن من اللاعب الجديد
    await c.env.DB.prepare(`
      UPDATE player_roles 
      SET is_current = 0, removed_at = CURRENT_TIMESTAMP
      WHERE room_id = ? AND user_id = ? AND is_current = 1
    `).bind(roomId, new_mutawahhish_user_id).run();
    
    // إضافة دور المتوحش للاعب الجديد
    await c.env.DB.prepare(`
      INSERT INTO player_roles (room_id, user_id, role_type, is_current, assigned_by_user_id)
      VALUES (?, ?, 'mutawahhish', 1, ?)
    `).bind(roomId, new_mutawahhish_user_id, user.id).run();
    
    // تسجيل حدث نقل الدور
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, event_type, event_data, user_id)
      VALUES (?, 'role_transfer', ?, ?)
    `).bind(roomId, JSON.stringify({ 
      old_mutawahhish: user.id,
      new_mutawahhish: new_mutawahhish_user_id 
    }), user.id).run();
    
    // إنهاء الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (round) {
      await c.env.DB.prepare(`
        UPDATE rounds SET ended_at = CURRENT_TIMESTAMP WHERE id = ?
      `).bind(round.id).run();
      
      // بدء جولة جديدة
      const newRoundNumber = round.round_number + 1;
      await c.env.DB.prepare(`
        INSERT INTO rounds (room_id, round_number, phase)
        VALUES (?, ?, 'kill')
      `).bind(roomId, newRoundNumber).run();
      
      await c.env.DB.prepare(`
        UPDATE rooms SET current_round = ? WHERE id = ?
      `).bind(newRoundNumber, roomId).run();
    }
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم نقل دور المتوحش بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في نقل الدور',
      message: error.message 
    }, 500);
  }
});

export default voteRoutes;
