// ==========================================
// Chat Routes
// ==========================================

import { Hono } from 'hono';
import { Env, ApiResponse, User, ChatMessage, SendMessageRequest } from '../types';
import { authMiddleware } from '../middleware/auth';

const chatRoutes = new Hono<{ Bindings: Env }>();

// تطبيق middleware المصادقة
chatRoutes.use('/*', authMiddleware);

/**
 * GET /api/chat/:roomId/messages
 * جلب رسائل الدردشة
 */
chatRoutes.get('/:roomId/messages', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const limit = parseInt(c.req.query('limit') || '50');
    const offset = parseInt(c.req.query('offset') || '0');
    
    const messages = await c.env.DB.prepare(`
      SELECT cm.*, u.username, u.display_name
      FROM chat_messages cm
      JOIN users u ON cm.user_id = u.id
      WHERE cm.room_id = ?
      ORDER BY cm.sent_at DESC
      LIMIT ? OFFSET ?
    `).bind(roomId, limit, offset).all();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { messages: messages.results.reverse() } // عكس الترتيب ليكون من الأقدم للأحدث
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب الرسائل',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/chat/:roomId/send
 * إرسال رسالة
 */
chatRoutes.post('/:roomId/send', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    const body: SendMessageRequest = await c.req.json();
    const { message_text } = body;
    
    if (!message_text || message_text.trim().length === 0) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'الرسالة فارغة' 
      }, 400);
    }
    
    if (message_text.length > 500) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'الرسالة طويلة جداً (الحد الأقصى 500 حرف)' 
      }, 400);
    }
    
    // التحقق من أن اللاعب في الغرفة
    const player = await c.env.DB.prepare(`
      SELECT * FROM room_players WHERE room_id = ? AND user_id = ? LIMIT 1
    `).bind(roomId, user.id).first();
    
    if (!player) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'يجب أن تكون في الغرفة لإرسال رسالة' 
      }, 403);
    }
    
    // إرسال الرسالة
    const result = await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, ?, 'text', ?)
    `).bind(roomId, user.id, message_text).run();
    
    if (!result.success) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'فشل في إرسال الرسالة' 
      }, 500);
    }
    
    // جلب الرسالة المرسلة
    const message = await c.env.DB.prepare(`
      SELECT cm.*, u.username, u.display_name
      FROM chat_messages cm
      JOIN users u ON cm.user_id = u.id
      WHERE cm.id = ?
      LIMIT 1
    `).bind(result.meta.last_row_id).first();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم إرسال الرسالة',
      data: { message }
    }, 201);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في إرسال الرسالة',
      message: error.message 
    }, 500);
  }
});

export default chatRoutes;
