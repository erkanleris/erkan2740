// ==========================================
// Admin Routes - لوحة تحكم المشرف
// ==========================================

import { Hono } from 'hono';
import { Env, ApiResponse, User } from '../types';
import { authMiddleware, adminMiddleware } from '../middleware/auth';

const adminRoutes = new Hono<{ Bindings: Env }>();

// تطبيق middleware المصادقة والمشرف
adminRoutes.use('/*', authMiddleware);
adminRoutes.use('/*', adminMiddleware);

/**
 * GET /api/admin/stats
 * جلب إحصائيات النظام
 */
adminRoutes.get('/stats', async (c) => {
  try {
    // إحصائيات المستخدمين
    const totalUsers = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM users
    `).first();
    
    const bannedUsers = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM users WHERE is_banned = 1
    `).first();
    
    const activeToday = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM users 
      WHERE date(last_login) = date('now')
    `).first();
    
    // إحصائيات الغرف
    const totalRooms = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM rooms
    `).first();
    
    const activeRooms = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM rooms WHERE status = 'playing'
    `).first();
    
    const waitingRooms = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM rooms WHERE status = 'waiting'
    `).first();
    
    const finishedGames = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM rooms WHERE status = 'finished'
    `).first();
    
    // إحصائيات الرسائل
    const totalMessages = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM chat_messages
    `).first();
    
    const messagesToday = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM chat_messages 
      WHERE date(sent_at) = date('now')
    `).first();
    
    // إحصائيات الأحداث
    const totalEvents = await c.env.DB.prepare(`
      SELECT COUNT(*) as count FROM game_events
    `).first();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: {
        users: {
          total: totalUsers?.count || 0,
          banned: bannedUsers?.count || 0,
          active_today: activeToday?.count || 0
        },
        rooms: {
          total: totalRooms?.count || 0,
          active: activeRooms?.count || 0,
          waiting: waitingRooms?.count || 0,
          finished: finishedGames?.count || 0
        },
        messages: {
          total: totalMessages?.count || 0,
          today: messagesToday?.count || 0
        },
        events: {
          total: totalEvents?.count || 0
        }
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب الإحصائيات',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/admin/users
 * جلب قائمة المستخدمين
 */
adminRoutes.get('/users', async (c) => {
  try {
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');
    const offset = (page - 1) * limit;
    const search = c.req.query('search') || '';
    
    let query = `
      SELECT id, username, email, display_name, is_admin, is_banned, 
             created_at, last_login, total_games, total_wins
      FROM users
    `;
    
    if (search) {
      query += ` WHERE username LIKE ? OR email LIKE ? OR display_name LIKE ?`;
    }
    
    query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    
    const users = search 
      ? await c.env.DB.prepare(query).bind(`%${search}%`, `%${search}%`, `%${search}%`, limit, offset).all()
      : await c.env.DB.prepare(query).bind(limit, offset).all();
    
    const total = await c.env.DB.prepare(`SELECT COUNT(*) as count FROM users`).first();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { 
        users: users.results,
        total: total?.count || 0,
        page,
        pageSize: limit
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب المستخدمين',
      message: error.message 
    }, 500);
  }
});

/**
 * PUT /api/admin/users/:userId/ban
 * حظر/إلغاء حظر مستخدم
 */
adminRoutes.put('/users/:userId/ban', async (c) => {
  try {
    const userId = c.req.param('userId');
    const { is_banned } = await c.req.json();
    
    await c.env.DB.prepare(`
      UPDATE users SET is_banned = ? WHERE id = ?
    `).bind(is_banned ? 1 : 0, userId).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: is_banned ? 'تم حظر المستخدم' : 'تم إلغاء حظر المستخدم'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في تحديث حالة المستخدم',
      message: error.message 
    }, 500);
  }
});

/**
 * PUT /api/admin/users/:userId/admin
 * تعيين/إزالة صلاحيات المشرف
 */
adminRoutes.put('/users/:userId/admin', async (c) => {
  try {
    const userId = c.req.param('userId');
    const { is_admin } = await c.req.json();
    
    await c.env.DB.prepare(`
      UPDATE users SET is_admin = ? WHERE id = ?
    `).bind(is_admin ? 1 : 0, userId).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: is_admin ? 'تم تعيين كمشرف' : 'تم إزالة صلاحيات المشرف'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في تحديث صلاحيات المستخدم',
      message: error.message 
    }, 500);
  }
});

/**
 * DELETE /api/admin/users/:userId
 * حذف مستخدم
 */
adminRoutes.delete('/users/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const currentUser = c.get('user') as User;
    
    if (currentUser.id.toString() === userId) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'لا يمكنك حذف حسابك الخاص' 
      }, 400);
    }
    
    await c.env.DB.prepare(`
      DELETE FROM users WHERE id = ?
    `).bind(userId).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم حذف المستخدم بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في حذف المستخدم',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/admin/rooms
 * جلب جميع الغرف
 */
adminRoutes.get('/rooms', async (c) => {
  try {
    const status = c.req.query('status');
    
    let query = `
      SELECT r.*, u.display_name as host_name,
             (SELECT COUNT(*) FROM room_players WHERE room_id = r.id) as player_count
      FROM rooms r
      JOIN users u ON r.host_user_id = u.id
    `;
    
    if (status) {
      query += ` WHERE r.status = ?`;
    }
    
    query += ` ORDER BY r.created_at DESC`;
    
    const rooms = status 
      ? await c.env.DB.prepare(query).bind(status).all()
      : await c.env.DB.prepare(query).all();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { rooms: rooms.results }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب الغرف',
      message: error.message 
    }, 500);
  }
});

/**
 * DELETE /api/admin/rooms/:roomId
 * حذف غرفة (المشرف يمكنه حذف أي غرفة)
 */
adminRoutes.delete('/rooms/:roomId', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    
    await c.env.DB.prepare(`
      DELETE FROM rooms WHERE id = ?
    `).bind(roomId).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم حذف الغرفة بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في حذف الغرفة',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/admin/events
 * جلب سجل الأحداث
 */
adminRoutes.get('/events', async (c) => {
  try {
    const limit = parseInt(c.req.query('limit') || '100');
    const roomId = c.req.query('room_id');
    
    let query = `
      SELECT ge.*, r.room_name, u.display_name as user_name
      FROM game_events ge
      LEFT JOIN rooms r ON ge.room_id = r.id
      LEFT JOIN users u ON ge.user_id = u.id
    `;
    
    if (roomId) {
      query += ` WHERE ge.room_id = ?`;
    }
    
    query += ` ORDER BY ge.created_at DESC LIMIT ?`;
    
    const events = roomId 
      ? await c.env.DB.prepare(query).bind(roomId, limit).all()
      : await c.env.DB.prepare(query).bind(limit).all();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { events: events.results }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب الأحداث',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/admin/cleanup
 * تنظيف البيانات القديمة
 */
adminRoutes.post('/cleanup', async (c) => {
  try {
    // حذف الجلسات المنتهية
    const expiredSessions = await c.env.DB.prepare(`
      DELETE FROM sessions WHERE expires_at < datetime('now')
    `).run();
    
    // حذف الغرف المنتهية القديمة (أكثر من 30 يوم)
    const oldRooms = await c.env.DB.prepare(`
      DELETE FROM rooms 
      WHERE status = 'finished' 
      AND datetime(finished_at) < datetime('now', '-30 days')
    `).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم التنظيف بنجاح',
      data: {
        expired_sessions: expiredSessions.meta.changes || 0,
        old_rooms: oldRooms.meta.changes || 0
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في التنظيف',
      message: error.message 
    }, 500);
  }
});

export default adminRoutes;
