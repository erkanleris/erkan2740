// ==========================================
// Rooms Routes
// ==========================================

import { Hono } from 'hono';
import { Env, ApiResponse, CreateRoomRequest, JoinRoomRequest, Room, RoomPlayer, User } from '../types';
import { authMiddleware, roomHostMiddleware } from '../middleware/auth';
import { generateRoomCode } from '../utils/auth';

const roomRoutes = new Hono<{ Bindings: Env }>();

// تطبيق middleware المصادقة على جميع المسارات
roomRoutes.use('/*', authMiddleware);

/**
 * POST /api/rooms
 * إنشاء غرفة جديدة
 */
roomRoutes.post('/', async (c) => {
  try {
    const user = c.get('user') as User;
    const body: CreateRoomRequest = await c.req.json();
    const { room_name, max_seats = 15, game_type = 'almutawahhish' } = body;
    
    // التحقق من صحة البيانات
    if (!room_name) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'اسم الغرفة مطلوب' 
      }, 400);
    }
    
    if (max_seats < 5 || max_seats > 20) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'عدد المقاعد يجب أن يكون بين 5 و 20' 
      }, 400);
    }
    
    // توليد كود غرفة فريد
    let roomCode = generateRoomCode();
    let attempts = 0;
    
    while (attempts < 10) {
      const existing = await c.env.DB.prepare(`
        SELECT id FROM rooms WHERE room_code = ? LIMIT 1
      `).bind(roomCode).first();
      
      if (!existing) break;
      
      roomCode = generateRoomCode();
      attempts++;
    }
    
    if (attempts >= 10) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'فشل في توليد كود فريد للغرفة' 
      }, 500);
    }
    
    // إنشاء الغرفة
    const result = await c.env.DB.prepare(`
      INSERT INTO rooms (room_code, room_name, game_type, host_user_id, max_seats, status)
      VALUES (?, ?, ?, ?, ?, 'waiting')
    `).bind(roomCode, room_name, game_type, user.id, max_seats).run();
    
    if (!result.success) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'فشل في إنشاء الغرفة' 
      }, 500);
    }
    
    const roomId = result.meta.last_row_id;
    
    // إضافة المضيف كأول لاعب في المقعد 1
    await c.env.DB.prepare(`
      INSERT INTO room_players (room_id, user_id, seat_number, is_host)
      VALUES (?, ?, 1, 1)
    `).bind(roomId, user.id).run();
    
    // تسجيل حدث إنشاء الغرفة
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, event_type, event_data, user_id)
      VALUES (?, 'game_start', ?, ?)
    `).bind(roomId, JSON.stringify({ room_name, max_seats }), user.id).run();
    
    // جلب الغرفة المنشأة
    const room = await c.env.DB.prepare(`
      SELECT * FROM rooms WHERE id = ? LIMIT 1
    `).bind(roomId).first();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم إنشاء الغرفة بنجاح',
      data: { room }
    }, 201);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في إنشاء الغرفة',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/rooms/join
 * الانضمام إلى غرفة
 */
roomRoutes.post('/join', async (c) => {
  try {
    const user = c.get('user') as User;
    const body: JoinRoomRequest = await c.req.json();
    const { room_code, seat_number } = body;
    
    // التحقق من صحة البيانات
    if (!room_code || !seat_number) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'كود الغرفة ورقم المقعد مطلوبان' 
      }, 400);
    }
    
    // البحث عن الغرفة
    const room = await c.env.DB.prepare(`
      SELECT * FROM rooms WHERE room_code = ? LIMIT 1
    `).bind(room_code).first() as Room | null;
    
    if (!room) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'الغرفة غير موجودة' 
      }, 404);
    }
    
    // التحقق من حالة الغرفة
    if (room.status !== 'waiting') {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'الغرفة قد بدأت بالفعل أو انتهت' 
      }, 400);
    }
    
    // التحقق من رقم المقعد
    if (seat_number < 1 || seat_number > room.max_seats) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: `رقم المقعد يجب أن يكون بين 1 و ${room.max_seats}` 
      }, 400);
    }
    
    // التحقق من أن المستخدم ليس في الغرفة بالفعل
    const existingPlayer = await c.env.DB.prepare(`
      SELECT id FROM room_players WHERE room_id = ? AND user_id = ? LIMIT 1
    `).bind(room.id, user.id).first();
    
    if (existingPlayer) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'أنت بالفعل في هذه الغرفة' 
      }, 400);
    }
    
    // التحقق من أن المقعد غير محجوز
    const existingSeat = await c.env.DB.prepare(`
      SELECT id FROM room_players WHERE room_id = ? AND seat_number = ? LIMIT 1
    `).bind(room.id, seat_number).first();
    
    if (existingSeat) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'هذا المقعد محجوز بالفعل' 
      }, 400);
    }
    
    // إضافة اللاعب إلى الغرفة
    const result = await c.env.DB.prepare(`
      INSERT INTO room_players (room_id, user_id, seat_number, is_host)
      VALUES (?, ?, ?, 0)
    `).bind(room.id, user.id, seat_number).run();
    
    if (!result.success) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'فشل في الانضمام إلى الغرفة' 
      }, 500);
    }
    
    // تسجيل حدث انضمام اللاعب
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, event_type, event_data, user_id)
      VALUES (?, 'player_join', ?, ?)
    `).bind(room.id, JSON.stringify({ seat_number }), user.id).run();
    
    // إضافة رسالة نظام
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, ?, 'system', ?)
    `).bind(room.id, user.id, `انضم ${user.display_name} إلى الغرفة في المقعد ${seat_number}`).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم الانضمام إلى الغرفة بنجاح',
      data: { room, seat_number }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في الانضمام إلى الغرفة',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/rooms/:roomId
 * جلب معلومات غرفة محددة
 */
roomRoutes.get('/:roomId', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    
    // جلب الغرفة
    const room = await c.env.DB.prepare(`
      SELECT * FROM rooms WHERE id = ? LIMIT 1
    `).bind(roomId).first();
    
    if (!room) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'الغرفة غير موجودة' 
      }, 404);
    }
    
    // جلب اللاعبين
    const players = await c.env.DB.prepare(`
      SELECT rp.*, u.username, u.display_name
      FROM room_players rp
      JOIN users u ON rp.user_id = u.id
      WHERE rp.room_id = ?
      ORDER BY rp.seat_number
    `).bind(roomId).all();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { 
        room, 
        players: players.results 
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب معلومات الغرفة',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/rooms
 * جلب قائمة الغرف المتاحة
 */
roomRoutes.get('/', async (c) => {
  try {
    const status = c.req.query('status') || 'waiting';
    
    const rooms = await c.env.DB.prepare(`
      SELECT r.*, u.display_name as host_name,
             (SELECT COUNT(*) FROM room_players WHERE room_id = r.id) as player_count
      FROM rooms r
      JOIN users u ON r.host_user_id = u.id
      WHERE r.status = ?
      ORDER BY r.created_at DESC
      LIMIT 50
    `).bind(status).all();
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { rooms: rooms.results }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب قائمة الغرف',
      message: error.message 
    }, 500);
  }
});

/**
 * DELETE /api/rooms/:roomId
 * حذف غرفة (مضيف الغرفة فقط)
 */
roomRoutes.delete('/:roomId', roomHostMiddleware, async (c) => {
  try {
    const roomId = c.req.param('roomId');
    
    // حذف الغرفة (سيتم حذف البيانات المرتبطة تلقائياً بسبب CASCADE)
    await c.env.DB.prepare(`
      DELETE FROM rooms WHERE id = ?
    `).bind(roomId).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم حذف الغرفة بنجاح'
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في حذف الغرفة',
      message: error.message 
    }, 500);
  }
});

export default roomRoutes;
