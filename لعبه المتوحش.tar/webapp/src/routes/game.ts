// ==========================================
// Game Logic Routes - لعبة المتوحش
// ==========================================

import { Hono } from 'hono';
import { Env, ApiResponse, User, Room, RoomPlayer, PlayerRole, Round } from '../types';
import { authMiddleware, roomHostMiddleware } from '../middleware/auth';
import { selectRandomMutawahhish, selectPulses, getHighestVotedPlayer, checkGameWin } from '../utils/game';

const gameRoutes = new Hono<{ Bindings: Env }>();

// تطبيق middleware المصادقة
gameRoutes.use('/*', authMiddleware);

/**
 * POST /api/game/:roomId/start
 * بدء اللعبة (المضيف فقط)
 */
gameRoutes.post('/:roomId/start', roomHostMiddleware, async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    
    // جلب الغرفة
    const room = await c.env.DB.prepare(`
      SELECT * FROM rooms WHERE id = ? LIMIT 1
    `).bind(roomId).first() as Room | null;
    
    if (!room) {
      return c.json<ApiResponse>({ success: false, error: 'الغرفة غير موجودة' }, 404);
    }
    
    if (room.status !== 'waiting') {
      return c.json<ApiResponse>({ success: false, error: 'اللعبة قد بدأت بالفعل' }, 400);
    }
    
    // جلب اللاعبين
    const players = await c.env.DB.prepare(`
      SELECT * FROM room_players WHERE room_id = ? AND is_alive = 1
    `).bind(roomId).all();
    
    const alivePlayers = players.results as RoomPlayer[];
    
    if (alivePlayers.length < 5) {
      return c.json<ApiResponse>({ success: false, error: 'يجب أن يكون هناك 5 لاعبين على الأقل' }, 400);
    }
    
    // اختيار متوحش عشوائي
    const mutawahhish = selectRandomMutawahhish(alivePlayers);
    
    if (!mutawahhish) {
      return c.json<ApiResponse>({ success: false, error: 'فشل في اختيار المتوحش' }, 500);
    }
    
    // تعيين دور المتوحش
    await c.env.DB.prepare(`
      INSERT INTO player_roles (room_id, user_id, role_type, is_current)
      VALUES (?, ?, 'mutawahhish', 1)
    `).bind(roomId, mutawahhish.user_id).run();
    
    // تعيين دور المواطنين لباقي اللاعبين
    for (const player of alivePlayers) {
      if (player.user_id !== mutawahhish.user_id) {
        await c.env.DB.prepare(`
          INSERT INTO player_roles (room_id, user_id, role_type, is_current)
          VALUES (?, ?, 'citizen', 1)
        `).bind(roomId, player.user_id).run();
      }
    }
    
    // تحديث حالة الغرفة
    await c.env.DB.prepare(`
      UPDATE rooms SET status = 'playing', started_at = CURRENT_TIMESTAMP, current_round = 1
      WHERE id = ?
    `).bind(roomId).run();
    
    // إنشاء الجولة الأولى
    await c.env.DB.prepare(`
      INSERT INTO rounds (room_id, round_number, phase)
      VALUES (?, 1, 'kill')
    `).bind(roomId).run();
    
    // تسجيل حدث بدء اللعبة
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, event_type, event_data, user_id)
      VALUES (?, 'game_start', ?, ?)
    `).bind(roomId, JSON.stringify({ player_count: alivePlayers.length }), user.id).run();
    
    // رسالة نظام
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, ?, 'system', ?)
    `).bind(roomId, user.id, 'بدأت اللعبة! تم تعيين الأدوار سراً').run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'بدأت اللعبة بنجاح',
      data: { 
        room_id: roomId,
        round: 1,
        phase: 'kill',
        player_count: alivePlayers.length
      }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في بدء اللعبة',
      message: error.message 
    }, 500);
  }
});

/**
 * GET /api/game/:roomId/my-role
 * جلب دور اللاعب الحالي (سري)
 */
gameRoutes.get('/:roomId/my-role', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    
    // جلب دور اللاعب الحالي
    const role = await c.env.DB.prepare(`
      SELECT * FROM player_roles 
      WHERE room_id = ? AND user_id = ? AND is_current = 1
      LIMIT 1
    `).bind(roomId, user.id).first() as PlayerRole | null;
    
    if (!role) {
      return c.json<ApiResponse>({ 
        success: false, 
        error: 'ليس لديك دور في هذه الغرفة' 
      }, 404);
    }
    
    return c.json<ApiResponse>({ 
      success: true,
      data: { role: role.role_type }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في جلب الدور',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/game/:roomId/kill
 * المتوحش يقتل لاعب (المتوحش فقط)
 */
gameRoutes.post('/:roomId/kill', async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const user = c.get('user') as User;
    const { target_user_id } = await c.req.json();
    
    // التحقق من أن المستخدم هو المتوحش
    const role = await c.env.DB.prepare(`
      SELECT * FROM player_roles 
      WHERE room_id = ? AND user_id = ? AND is_current = 1 AND role_type = 'mutawahhish'
      LIMIT 1
    `).bind(roomId, user.id).first();
    
    if (!role) {
      return c.json<ApiResponse>({ success: false, error: 'يجب أن تكون متوحشاً للقيام بهذا' }, 403);
    }
    
    // جلب الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (!round || round.phase !== 'kill') {
      return c.json<ApiResponse>({ success: false, error: 'ليس وقت القتل الآن' }, 400);
    }
    
    // التحقق من أن الهدف حي
    const target = await c.env.DB.prepare(`
      SELECT * FROM room_players 
      WHERE room_id = ? AND user_id = ? AND is_alive = 1
      LIMIT 1
    `).bind(roomId, target_user_id).first() as RoomPlayer | null;
    
    if (!target) {
      return c.json<ApiResponse>({ success: false, error: 'اللاعب المستهدف غير موجود أو ميت' }, 400);
    }
    
    if (target.user_id === user.id) {
      return c.json<ApiResponse>({ success: false, error: 'لا يمكنك قتل نفسك' }, 400);
    }
    
    // قتل اللاعب
    await c.env.DB.prepare(`
      UPDATE room_players 
      SET is_alive = 0, killed_at = CURRENT_TIMESTAMP
      WHERE room_id = ? AND user_id = ?
    `).bind(roomId, target_user_id).run();
    
    // تحديث الجولة
    await c.env.DB.prepare(`
      UPDATE rounds 
      SET killed_user_id = ?, phase = 'pulse'
      WHERE id = ?
    `).bind(target_user_id, round.id).run();
    
    // إذا كان المقتول متوحشاً، إزالة دوره
    await c.env.DB.prepare(`
      UPDATE player_roles 
      SET is_current = 0, removed_at = CURRENT_TIMESTAMP
      WHERE room_id = ? AND user_id = ? AND is_current = 1
    `).bind(roomId, target_user_id).run();
    
    // تسجيل حدث القتل
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, round_id, event_type, event_data, user_id)
      VALUES (?, ?, 'player_kill', ?, ?)
    `).bind(roomId, round.id, JSON.stringify({ killed_user_id: target_user_id }), user.id).run();
    
    // رسالة نظام
    const killedUser = await c.env.DB.prepare(`
      SELECT display_name FROM users WHERE id = ? LIMIT 1
    `).bind(target_user_id).first();
    
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES (?, ?, 'announcement', ?)
    `).bind(roomId, user.id, `تم إعلان خروج ${killedUser?.display_name} من اللعبة`).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم قتل اللاعب بنجاح',
      data: { killed_user_id: target_user_id, next_phase: 'pulse' }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في قتل اللاعب',
      message: error.message 
    }, 500);
  }
});

/**
 * POST /api/game/:roomId/pulse
 * المضيف يعلن النبضين (المضيف فقط)
 */
gameRoutes.post('/:roomId/pulse', roomHostMiddleware, async (c) => {
  try {
    const roomId = c.req.param('roomId');
    const { near_pulse_user_id, far_pulse_user_id } = await c.req.json();
    
    // جلب الجولة الحالية
    const round = await c.env.DB.prepare(`
      SELECT * FROM rounds 
      WHERE room_id = ? AND ended_at IS NULL
      ORDER BY round_number DESC
      LIMIT 1
    `).bind(roomId).first() as Round | null;
    
    if (!round || round.phase !== 'pulse') {
      return c.json<ApiResponse>({ success: false, error: 'ليس وقت إعلان النبض الآن' }, 400);
    }
    
    // تحديث الجولة
    await c.env.DB.prepare(`
      UPDATE rounds 
      SET near_pulse_user_id = ?, far_pulse_user_id = ?, phase = 'vote'
      WHERE id = ?
    `).bind(near_pulse_user_id, far_pulse_user_id, round.id).run();
    
    // تسجيل حدث النبض
    await c.env.DB.prepare(`
      INSERT INTO game_events (room_id, round_id, event_type, event_data)
      VALUES (?, ?, 'pulse_announce', ?)
    `).bind(roomId, round.id, JSON.stringify({ 
      near_pulse_user_id, 
      far_pulse_user_id 
    })).run();
    
    // رسائل نظام للنبضات
    const nearUser = await c.env.DB.prepare(`
      SELECT u.display_name, rp.seat_number 
      FROM users u 
      JOIN room_players rp ON u.id = rp.user_id 
      WHERE u.id = ? AND rp.room_id = ? 
      LIMIT 1
    `).bind(near_pulse_user_id, roomId).first();
    
    const farUser = await c.env.DB.prepare(`
      SELECT u.display_name, rp.seat_number 
      FROM users u 
      JOIN room_players rp ON u.id = rp.user_id 
      WHERE u.id = ? AND rp.room_id = ? 
      LIMIT 1
    `).bind(far_pulse_user_id, roomId).first();
    
    await c.env.DB.prepare(`
      INSERT INTO chat_messages (room_id, user_id, message_type, message_text)
      VALUES 
        (?, 1, 'announcement', ?),
        (?, 1, 'announcement', ?)
    `).bind(
      roomId, `نبض قريب: المقعد ${nearUser?.seat_number} - ${nearUser?.display_name}`,
      roomId, `نبض بعيد: المقعد ${farUser?.seat_number} - ${farUser?.display_name}`
    ).run();
    
    return c.json<ApiResponse>({ 
      success: true,
      message: 'تم إعلان النبضات بنجاح',
      data: { next_phase: 'vote' }
    }, 200);
    
  } catch (error: any) {
    return c.json<ApiResponse>({ 
      success: false, 
      error: 'خطأ في إعلان النبض',
      message: error.message 
    }, 500);
  }
});

export default gameRoutes;
